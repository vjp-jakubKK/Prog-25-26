/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package examenjakub;

/**
 *
 * @author alumno
 */
public interface Pedaleable {
    public void Sprintar(float kmMeta, float energia, float velocidad);
    public void Atacar(boolean estaEscapado, float hidratacion);
    public float recuperar(float kmMeta, float energia);
}
